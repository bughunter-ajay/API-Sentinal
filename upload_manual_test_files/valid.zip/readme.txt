API Sentinel zip baseline
